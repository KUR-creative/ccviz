# shlab
csapp 3e shlab

more information:  
http://csapp.cs.cmu.edu/3e/shlab.pdf  

최초 커밋 2017/1/13  
최후 커밋 2017/2/6  
진행 기간 25일  
실질 기간 11  

* Generated  
2017-02-06 16:30:15 (in 1 seconds)  

* Generator  
GitStats (version 2015.10.03), git version 2.7.4, gnuplot 4.6 patchlevel 6  

* Report Period  
2017-01-13 14:52:09 to 2017-02-06 14:48:22  

* Age  
25 days, 11 active days (44.00%)  

* Total Files  
31  

* Total Lines of Code  
3313 (4351 added, 1038 removed)  

* Total Commits  
53 (average 4.8 commits per active day, 2.1 per all days)  
